# Git The Flag

A friend of ours lost his flag in the dark realms of git.
Help him out.